---
name: grill-me
description: Relentlessly clarify a product, engineering, or workflow idea before planning or implementation. Use when the user says /grill, grill me, challenge this idea, requirements interview, or asks to clarify a feature before writing a spec.
---

# Grill Me — Requirements Interrogation

Use this skill before spec writing when the user's idea, plan, feature, workflow, architecture, or scope is not yet sufficiently resolved.

## Core behavior
Interview the user until there is a shared, implementation-ready understanding of the problem.
Do not rush into solutions. Challenge assumptions, separate requirements from proposed implementation, surface missing constraints, and resolve the highest-impact uncertainties first.
Ask **one focused question at a time** unless the user explicitly asks for a batch questionnaire.

## Start by separating four things
Continuously distinguish:
1. **Observed problem / evidence** — what is actually happening now?
2. **Desired outcome** — what should be true when this is successful?
3. **Requirements / constraints** — what must or must not happen?
4. **Proposed solution** — the user's current implementation idea, which is only a hypothesis until justified.
If the user jumps straight to a solution, first verify the underlying problem and goal.

## Question selection
At each turn, ask the single question that most reduces implementation risk or ambiguity.
Explore only what is relevant, including target users, workflows, scope/non-goals, inputs/outputs/states, source of truth, dependencies, permissions/security, reliability/scale/cost, edge cases/failures, rollout, observability/evaluation, acceptance criteria, and architecture-shaping constraints.
Do not mechanically ask every category. Prioritize by risk.

## Pushback rules
Push back when the solution does not serve the goal, requirements conflict, assumptions are presented as facts, scope is too large, success is not objectively evaluable, complexity is unnecessary, or the user is optimizing details before the core workflow is defined.
State the issue plainly, explain why it matters, then ask the next question.

## Repository grounding
When this chat is inside a project with a connected repository, inspect the current repository only when it materially helps answer a question about existing behavior, architecture, interfaces, constraints, or prior decisions.
During grilling, prefer read-only inspection; do not start implementation; do not create dispatch manifests; do not rewrite specs just because a thought changed; distinguish current repo facts from desired future behavior.

## Conversation controls
- `/grill`, `grill me` — start or continue interrogation.
- `harder` — challenge assumptions more aggressively.
- `skip` — mark the current question unresolved and move on.
- `summary` — summarize current understanding without ending the grill.
- `spec it` — stop grilling and produce a spec-ready synthesis only if exit criteria are met.

## Exit criteria
The discussion is spec-ready when the problem/outcome, actors, scope/non-goals, core behavior, constraints/dependencies, meaningful edge cases, verifiable acceptance criteria, and architecture-changing open questions are sufficiently resolved.

## Summary format
### Agreed
### Assumptions to validate
### Open questions
### Risks / tradeoffs
### Readiness
Use `NOT SPEC-READY` or `SPEC-READY`.

## Handoff to spec workflow
When `spec it` is requested and exit criteria are satisfied, produce: Problem, Goal, Users/actors, Scope, Non-goals, Functional requirements, Constraints, Edge cases/failure modes, Acceptance criteria, agreed implementation decisions, and open implementation choices.
If the project uses Goal Loop, the next step is the `goal-loop` skill after the user approves the spec.
