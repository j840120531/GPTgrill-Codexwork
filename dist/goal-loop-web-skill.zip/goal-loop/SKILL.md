---
name: goal-loop
description: Turn an approved ChatGPT planning discussion into repo-backed specs, phases, tasks, and a Goal Loop dispatch manifest for autonomous local Codex execution. Use when the user says /goal task, /goal phase, /goal full, /loop, dispatch this plan, or asks to hand an approved spec to local Codex.
---

# Goal Loop — ChatGPT Web Skill

Use this only after the requirements are sufficiently resolved. If the user is still exploring what they want, use their grilling/spec workflow first rather than dispatching prematurely.

## Purpose
ChatGPT is the requirements/spec/review layer. Local Codex is the implementation layer. Goal Loop bridges them through durable repo artifacts.

## Before dispatch
1. Inspect the connected repository and its current planning artifacts.
2. Confirm the problem, scope, non-goals, constraints, acceptance criteria, and important implementation decisions are explicit.
3. Prefer vertical-slice tasks that are independently verifiable. Do not split only by technical layer.
4. Do not mark a goal ready if unresolved questions could materially change implementation.

## Durable artifacts
Write or update:
- `specs/<goal-id>/SPEC.md`
- `specs/<goal-id>/PHASES.md` when multiple phases are useful
- `specs/<goal-id>/tasks/<task-id>.md` for each executable task
- `.goal-loop/dispatch/<goal-id>.json`
Each task must include Objective, Acceptance Criteria, Constraints, and Out of Scope.

## Modes
- `/goal task` -> `mode: "task"`
- `/goal phase` -> `mode: "phase"` (recommended default)
- `/goal full` or `/loop` -> `mode: "goal"`

## Revision gate
Every manifest has integer `revision` starting at 1. For task/phase modes, increment only after explicit user approval to continue. If blocked and resolved, update artifacts and increment revision.

## Dispatch schema
Required: `schemaVersion: 1`, `revision`, `goalId`, `title`, `status`, `mode`, `spec`, non-empty `phases[]` and `tasks[]`. Paths must be repo-relative and cannot traverse outside the repo.

## Safety / ownership
Keep runtime state out of Git. Never put secrets in specs/dispatch. Goal Loop owns autonomous commits/pushes; Codex should not commit/push. Do not use full-goal autonomy for destructive or high-impact changes needing explicit approval.

## Phase reporting
After a phase, inspect `goal-loop/<goal-id>` and `reports/<goal-id>/<phase-id>.md` when status is requested. Summarize completed tasks, verification, decisions, blockers, and next phase. For task/phase modes, wait for explicit approval before incrementing revision.
